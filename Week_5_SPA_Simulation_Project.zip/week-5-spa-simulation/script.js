"use strict";

document.addEventListener("DOMContentLoaded", function () {
  const app = document.querySelector("#app-content");
  const routeLinks = document.querySelectorAll("[data-route]");
  const year = document.querySelector("#year");

  if (year) year.textContent = new Date().getFullYear();

  const pages = {
    home: `
      <article class="hero-card">
        <p class="eyebrow">WELCOME TO MY SPA</p>
        <h1>Hi, I'm Anurag.<br><span>Frontend Developer</span></h1>
        <p>A Computer Science and Technology diploma student learning to build useful, responsive and accessible web experiences.</p>
        <a class="button" href="#projects">Explore Projects</a>
        <a class="button secondary" href="#about">About Me</a>
      </article>`,
    projects: `
      <section>
        <p class="eyebrow">WHAT I'M BUILDING</p>
        <h1 class="section-heading">My Projects</h1>
        <div class="grid">
          <article class="card"><span class="tag">HTML + CSS</span><h2>Responsive Portfolio</h2><p>A personal website that adapts to mobile, tablet and desktop screens.</p></article>
          <article class="card"><span class="tag">Accessibility</span><h2>Accessible Webpage</h2><p>A page focused on semantic structure, readable content and keyboard navigation.</p></article>
          <article class="card"><span class="tag">JavaScript</span><h2>SPA Simulation</h2><p>This project demonstrates client-side navigation without full page reloads.</p></article>
          <article class="card"><span class="tag">Learning</span><h2>Next Steps</h2><p>Continue improving JavaScript, UI design, and frontend development skills.</p></article>
        </div>
      </section>`,
    about: `
      <article class="card">
        <p class="eyebrow">A LITTLE ABOUT ME</p>
        <h1 class="section-heading">About Me</h1>
        <p>I'm a Diploma Polytechnic student specializing in Computer Science and Technology.</p>
        <p>I'm interested in frontend development, UI/UX design and software engineering. I enjoy learning by building practical projects and improving them through testing.</p>
        <h2>Technologies I'm learning</h2>
        <p><span class="tag">HTML5</span> <span class="tag">CSS3</span> <span class="tag">JavaScript</span> <span class="tag">GitHub</span></p>
      </article>`,
    contact: `
      <section class="contact-panel">
        <p class="eyebrow">LET'S CONNECT</p>
        <h1 class="section-heading">Contact Me</h1>
        <p>This demonstration form checks the fields in your browser. It does not send or store messages.</p>
        <form class="contact-form" id="contact-form">
          <div><label for="contact-name">Your name</label><input id="contact-name" name="name" autocomplete="name" required minlength="2" maxlength="80"></div>
          <div><label for="contact-email">Email address</label><input id="contact-email" name="email" type="email" autocomplete="email" required maxlength="254"></div>
          <div><label for="contact-message">Message</label><textarea id="contact-message" name="message" rows="4" required minlength="10" maxlength="1500"></textarea></div>
          <button class="button" type="submit">Validate Message</button>
          <p class="status" id="form-status" role="status" aria-live="polite"></p>
        </form>
      </section>`
  };

  function getRoute() {
    const route = window.location.hash.slice(1).split("?")[0];
    return Object.prototype.hasOwnProperty.call(pages, route) ? route : "home";
  }

  function renderRoute() {
    if (!app) return;

    const route = getRoute();
    app.innerHTML = pages[route];

    routeLinks.forEach(function (link) {
      if (link.dataset.route === route) {
        link.setAttribute("aria-current", "page");
      } else {
        link.removeAttribute("aria-current");
      }
    });

    const form = app.querySelector("#contact-form");
    if (form) {
      form.addEventListener("submit", function (event) {
        event.preventDefault();
        const status = form.querySelector("#form-status");
        if (!form.checkValidity()) {
          form.reportValidity();
          if (status) status.textContent = "Please complete all fields correctly.";
          return;
        }
        if (status) status.textContent = "Validation successful. This demo does not send your message.";
      });
      form.addEventListener("input", function () {
        const status = form.querySelector("#form-status");
        if (status) status.textContent = "";
      });
    }
  }

  // Let normal browser hash navigation work, then render the selected view.
  window.addEventListener("hashchange", renderRoute);

  // Initialize the view based on the current URL, including direct links.
  if (!window.location.hash || !pages[window.location.hash.slice(1)]) {
    history.replaceState({ route: "home" }, "", "#home");
  }

  renderRoute();
});
