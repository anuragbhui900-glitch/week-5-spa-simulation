# Week 5: Single Page Application (SPA) Simulation

**Student:** Anurag  
**Internship:** YuvaIntern — Frontend Web Developer  
**Technologies:** HTML5, CSS3, JavaScript

## Project overview
This project simulates a small single page application. The shared HTML shell remains in place while JavaScript dynamically renders Home, Projects, About, and Contact views. Hash-based routes update the URL without a full page reload.

## Files
- `index.html` — shared layout, navigation, and content container.
- `style.css` — responsive styles, cards, focus states, and reduced-motion support.
- `script.js` — route selection, dynamic rendering, active navigation state, and form validation.
- `README.md` — project documentation.

## How to run
1. Extract the project ZIP.
2. Open the folder in Visual Studio Code.
3. Open `index.html` with Live Server, or open it directly in a modern browser.
4. Use the navigation links to move between Home, Projects, About, and Contact.

## SPA features
- Dynamic content updates without a full document reload.
- URL hash routes: `#home`, `#projects`, `#about`, and `#contact`.
- Browser Back and Forward support through the `hashchange` event.
- Direct links to routes are supported.
- Unknown routes fall back to the Home view.
- Active navigation is indicated using `aria-current`.
- Responsive layout and keyboard focus indicators.
- Contact form uses browser validation; it does not send or store data.

## Testing checklist
- Select each navigation item and check that content changes.
- Verify the URL hash changes to match the view.
- Use browser Back and Forward and confirm the view updates.
- Open `index.html#projects` directly.
- Try an unknown hash and confirm the app falls back to Home.
- Resize the browser to mobile and desktop widths.
- Navigate with the keyboard and inspect the console for errors.
- Submit the contact form with missing and valid values.

## Implementation notes
The application uses vanilla JavaScript and the URL hash for simple client-side routing. The `hashchange` event triggers rendering when the URL fragment changes, including browser history navigation. Content is stored in a route-to-template object. This is a learning simulation, not a production router; a larger app may use a dedicated routing library and server fallback configuration.
